import dash
from dash import dcc, html, dash_table
import dash_bootstrap_components as dbc
import pandas as pd

# Load data from CSV
df = pd.read_csv("all_centers.csv")
all_divisions_df = pd.read_csv("all_divisions.csv")

# Strip leading/trailing spaces from column names
df.columns = df.columns.str.strip()
all_divisions_df.columns = all_divisions_df.columns.str.strip()

# Precompute descriptive statistics
total_centers = df["S/N"].count()
unique_regions = df["Region"].nunique()
unique_divisions = df["Division Name"].nunique()

# Total number of divisions in Cameroon (from all_divisions.csv)
total_divisions_cameroon = all_divisions_df["Division Name"].nunique()
divisions_not_represented = total_divisions_cameroon - unique_divisions

# Frequency of Centers by Region
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "Count"]

# Top 5 and Bottom 5 Regions
top_5_regions = region_freq.head(5)
bottom_5_regions = region_freq.tail(5)

# Frequency of Centers by Division
division_freq = df.groupby(["Division Name", "Region"]).size().reset_index(name="Count")

# Top 10 and Bottom 10 Divisions
top_10_divisions = division_freq.nlargest(10, "Count")
bottom_10_divisions = division_freq.nsmallest(10, "Count")

# List of Divisions with No Centers
divisions_with_centers = df["Division Name"].unique()
divisions_with_no_centers = all_divisions_df[~all_divisions_df["Division Name"].isin(divisions_with_centers)]

# Centre Names Analysis
keywords = ["government", "external", "secondary", "high", "college", "comprehensive", "technical"]
denominations = ["catholic", "protestant", "presbyterian", "baptist", "saint"]
towns = [
    "edea", "kumba", "limbe", "nkongsamba", "dschang", "kribi", "tiko", "foumban", "mokolo", "yagoua"
]
capital_cities = ["yaounde", "douala", "bamenda", "bafoussam", "garoua", "maroua", "bertoua", "ngaoundere", "ebolowa", "buea"]

# Count occurrences of keywords in Centre Names
keyword_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in keywords}
keyword_freq = pd.DataFrame(list(keyword_counts.items()), columns=["Keyword", "Count"])
keyword_freq["Keyword"] = keyword_freq["Keyword"].str.title()  # Convert to title case
keyword_freq = keyword_freq.sort_values(by="Count", ascending=False)  # Sort by Count

# Count occurrences of denominational words in Centre Names
denomination_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in denominations}
denomination_freq = pd.DataFrame(list(denomination_counts.items()), columns=["Denomination", "Count"])
denomination_freq["Denomination"] = denomination_freq["Denomination"].str.title()  # Convert to title case
denomination_freq = denomination_freq.sort_values(by="Count", ascending=False)  # Sort by Count

# Count occurrences of popular towns in Centre Names
town_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in towns}
town_freq = pd.DataFrame(list(town_counts.items()), columns=["Town", "Count"])
town_freq["Town"] = town_freq["Town"].str.title()  # Convert to title case
town_freq = town_freq.sort_values(by="Count", ascending=False)  # Sort by Count

# Count occurrences of capital cities in Centre Names
capital_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in capital_cities}
capital_freq = pd.DataFrame(list(capital_counts.items()), columns=["Capital", "Count"])
capital_freq["Capital"] = capital_freq["Capital"].str.title()  # Convert to title case
capital_freq = capital_freq.sort_values(by="Count", ascending=False)  # Sort by Count

# Additional Descriptive Statistics
avg_centers_per_region = region_freq["Count"].mean()
median_centers_per_region = region_freq["Count"].median()
std_centers_per_region = region_freq["Count"].std()
max_centers_per_region = region_freq["Count"].max()

avg_centers_per_division = division_freq["Count"].mean()
median_centers_per_division = division_freq["Count"].median()
std_centers_per_division = division_freq["Count"].std()
max_centers_per_division = division_freq["Count"].max()

# Centre Name Analysis
from collections import Counter
import re

words = " ".join(df["Centre Name"].str.lower()).split()
words = [re.sub(r"[^\w]", "", word) for word in words]  # Remove punctuation
words = [word for word in words if word not in ["of", "the", "and", "in"]]  # Exclude stopwords
most_common_words = Counter(words).most_common(5)  # Top 5 most common words

unique_centre_names = df["Centre Name"].nunique()

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Include FontAwesome CSS
app.layout = html.Div([
    html.Link(
        rel="stylesheet",
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    ),
    # Your existing layout
])

# Custom styles
card_style = {
    "textAlign": "center",
    "fontSize": "24px",
    "fontWeight": "bold",
    "border": "1px solid #ddd",
    "boxShadow": "2px 2px 5px rgba(0,0,0,0.1)",
    "backgroundColor": "#f8f9fa"
}

header_style = {
    "textAlign": "center",
    "backgroundColor": "#343a40",
    "color": "white",
    "padding": "10px",
    "borderBottom": "1px solid #ddd"
}

section_style = {
    "padding": "20px",
    "marginBottom": "20px",
    "border": "1px solid #ddd",
    "borderRadius": "5px",
    "backgroundColor": "#ffffff",
    "boxShadow": "2px 2px 10px rgba(0,0,0,0.1)"
}

footer_style = {
    "backgroundColor": "#343a40",
    "color": "white",
    "textAlign": "center",
    "padding": "10px",
    "position": "fixed",
    "left": "0",
    "bottom": "0",
    "width": "100%"
}

# Table styling
table_style = {
    "fontFamily": "Arial, sans-serif",
    "border": "1px solid #ddd",
    "borderRadius": "5px",
    "boxShadow": "2px 2px 5px rgba(0,0,0,0.1)"
}

table_header_style = {
    "backgroundColor": "#343a40",
    "color": "white",
    "fontWeight": "bold"
}

table_cell_style = {
    "textAlign": "left",
    "padding": "10px"
}

# Layout
app.layout = dbc.Container([
    # Header
    dbc.Row([
        dbc.Col(html.H1("Centers Dashboard", style={"textAlign": "center", "color": "#343a40"}), width=12),
        dbc.Col(html.P("Global Descriptive Statistics and Analysis", style={"textAlign": "center", "color": "#6c757d"}), width=12)
    ], style={"marginBottom": "20px"}),
    
    # Top Section: Global Statistics
    html.Div([
        html.H3("Global Statistics", style={"textAlign": "center", "color": "#343a40", "marginBottom": "20px"}),
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-school me-2"), "Total Centers"]), style=header_style),
                dbc.CardBody(f"{total_centers}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-map-marked-alt me-2"), "Unique Regions"]), style=header_style),
                dbc.CardBody(f"{unique_regions}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-layer-group me-2"), "Unique Divisions"]), style=header_style),
                dbc.CardBody(f"{unique_divisions}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-exclamation-circle me-2"), "Divisions Not Represented"]), style=header_style),
                dbc.CardBody(f"{divisions_not_represented}", style=card_style)
            ]), width=3)
        ]),
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-chart-line me-2"), "Avg Centers per Region"]), style=header_style),
                dbc.CardBody(f"{avg_centers_per_region:.2f}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-sort-amount-up me-2"), "Median Centers per Region"]), style=header_style),
                dbc.CardBody(f"{median_centers_per_region}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-chart-bar me-2"), "Std Dev Centers per Region"]), style=header_style),
                dbc.CardBody(f"{std_centers_per_region:.2f}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-trophy me-2"), "Max Centers per Region"]), style=header_style),
                dbc.CardBody(f"{max_centers_per_region}", style=card_style)
            ]), width=3)
        ]),
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-chart-line me-2"), "Avg Centers per Division"]), style=header_style),
                dbc.CardBody(f"{avg_centers_per_division:.2f}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-sort-amount-up me-2"), "Median Centers per Division"]), style=header_style),
                dbc.CardBody(f"{median_centers_per_division}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-chart-bar me-2"), "Std Dev Centers per Division"]), style=header_style),
                dbc.CardBody(f"{std_centers_per_division:.2f}", style=card_style)
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader(html.Span([html.I(className="fas fa-trophy me-2"), "Max Centers per Division"]), style=header_style),
                dbc.CardBody(f"{max_centers_per_division}", style=card_style)
            ]), width=3)
        ])
    ], style=section_style),
    
    # Mid Section: Regional and Divisional Analysis
    html.Div([
        html.H3("Regional and Divisional Analysis", style={"textAlign": "center", "color": "#343a40", "marginBottom": "20px"}),
        dbc.Row([
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-arrow-up me-2"), "Top 5 Regions"]), style={"color": "green"}),
                dash_table.DataTable(
                    columns=[{"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                    data=top_5_regions.to_dict("records"),
                    style_table={"height": "200px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                ),
                html.H4(html.Span([html.I(className="fas fa-arrow-down me-2"), "Bottom 5 Regions"]), style={"color": "red"}),
                dash_table.DataTable(
                    columns=[{"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                    data=bottom_5_regions.to_dict("records"),
                    style_table={"height": "200px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-arrow-up me-2"), "Top 10 Divisions"]), style={"color": "green"}),
                dash_table.DataTable(
                    columns=[{"name": "Division Name", "id": "Division Name"}, {"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                    data=top_10_divisions.to_dict("records"),
                    style_table={"height": "400px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-arrow-down me-2"), "Bottom 10 Divisions"]), style={"color": "red"}),
                dash_table.DataTable(
                    columns=[{"name": "Division Name", "id": "Division Name"}, {"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                    data=bottom_10_divisions.to_dict("records"),
                    style_table={"height": "400px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-times-circle me-2"), "Divisions with 0 Centers"]), style={"color": "gray"}),
                dash_table.DataTable(
                    columns=[{"name": "Region", "id": "Region"}, {"name": "Division Name", "id": "Division Name"}],
                    data=divisions_with_no_centers.to_dict("records"),
                    style_table={"height": "400px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3)
        ])
    ], style=section_style),
    
    # Bottom Section: Centre Name Insights
    html.Div([
        html.H3("Centre Name Insights", style={"textAlign": "center", "color": "#343a40", "marginBottom": "20px"}),
        dbc.Row([
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-key me-2"), "Types of Centers - Keywords in Names"])),
                dash_table.DataTable(
                    columns=[{"name": "Keyword", "id": "Keyword"}, {"name": "Count", "id": "Count"}],
                    data=keyword_freq.to_dict("records"),
                    style_table={"height": "300px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-church me-2"), "Denominational Words in Centre Names"])),
                dash_table.DataTable(
                    columns=[{"name": "Denomination", "id": "Denomination"}, {"name": "Count", "id": "Count"}],
                    data=denomination_freq.to_dict("records"),
                    style_table={"height": "300px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-city me-2"), "Capitals in Centre Names"])),
                dash_table.DataTable(
                    columns=[{"name": "Capital", "id": "Capital"}, {"name": "Count", "id": "Count"}],
                    data=capital_freq.to_dict("records"),
                    style_table={"height": "400px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3),
            dbc.Col([
                html.H4(html.Span([html.I(className="fas fa-map-marker-alt me-2"), "Popular Towns in Centre Names"])),
                dash_table.DataTable(
                    columns=[{"name": "Town", "id": "Town"}, {"name": "Count", "id": "Count"}],
                    data=town_freq.to_dict("records"),
                    style_table={"height": "400px", "overflowY": "auto", **table_style},
                    style_header=table_header_style,
                    style_cell=table_cell_style
                )
            ], width=3)
        ])
    ], style=section_style),
    
    # Footer
    html.Footer([
        html.P("© 2025 GCE Centers Dashboard. All rights reserved. Created by Vi-2s-Dk Foundation (vi2sdk.com)", style={"margin": "0"})
    ], style=footer_style)
], fluid=True)

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)