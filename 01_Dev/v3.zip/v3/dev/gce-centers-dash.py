import dash
from dash import dcc, html, dash_table
import pandas as pd
import plotly.express as px

# Load the DataFrame from the PDF (output: csv)
df = pd.read_csv("all_centers.csv")
print(df.describe())

# Create Dash app
app = dash.Dash(__name__)

# Layout of the dashboard
app.layout = html.Div([
    html.H1("2024 GCE Advanced Levels - Centre Insights", style={"textAlign": "center"}),
    
    # Filters
    html.Div([
        html.Label("Filter by Region:"),
        dcc.Dropdown(
            id="region-dropdown",
            options=[{"label": region, "value": region} for region in df["Region"].unique()],
            value=df["Region"].unique()[0],  # Default value
            clearable=False,
            style={"width": "50%"}
        ),
        html.Br(),
        html.Label("Filter by Division:"),
        dcc.Dropdown(
            id="division-dropdown",
            options=[{"label": division, "value": division} for division in sorted(df["Division Name"].unique())],
            value=sorted(df["Division Name"].unique()),  # Default value (all selected)
            multi=True,
            style={"width": "50%"}
        )
    ], style={"padding": "20px"}),
    
    
    # Charts
    html.Div([
        dcc.Graph(id="division-bar-chart"),
        dcc.Graph(id="division-pie-chart")
    ], style={"display": "flex", "justifyContent": "space-around", "padding": "20px"}),

    # Data Table
    dash_table.DataTable(
        id="centre-table",
        columns=[{"name": col, "id": col} for col in df.columns],
        data=df.to_dict("records"),
        page_size=20,
        filter_action="native",
        sort_action="native",
        style_table={"height": "900px", "overflowY": "auto"},
        style_cell={"textAlign": "left", "padding": "10px"},
        style_header={"backgroundColor": "lightblue", "fontWeight": "bold"}
    ),
])

# Callback to update the table and charts based on filters
@app.callback(
    [dash.dependencies.Output("centre-table", "data"),
     dash.dependencies.Output("division-bar-chart", "figure"),
     dash.dependencies.Output("division-pie-chart", "figure")],
    [dash.dependencies.Input("region-dropdown", "value"),
     dash.dependencies.Input("division-dropdown", "value")]
)
def update_dashboard(selected_region, selected_divisions):
    # Filter the DataFrame
    filtered_df = df[(df["Region"] == selected_region) & (df["Division Name"].isin(selected_divisions))]
    
    # Update the table
    table_data = filtered_df.to_dict("records")
    
    # Update the bar chart
    division_counts = filtered_df["Division Name"].value_counts().reset_index()
    division_counts.columns = ["Division Name", "count"]  # Rename columns
    bar_chart = px.bar(
        division_counts,
        x="Division Name",
        y="count",
        labels={"Division Name": "Division Name", "count": "Number of centres"},
        title=f"Distribution of Divisions in {selected_region}"
    )
    
    # Update the pie chart
    division_counts = filtered_df["Division Name"].value_counts().reset_index()
    division_counts.columns = ["Division Name", "count"]  # Rename columns
    pie_chart = px.pie(
        division_counts,
        names="Division Name",
        values="count",
        title=f"Percentage of Centres by Division in {selected_region}"
    )
    return table_data, bar_chart, pie_chart

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)