import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load the merged CSV file
df = pd.read_csv("merged_centers.csv")

# Clean the Region and Division Name columns (remove leading/trailing spaces)
df["Region"] = df["Region"].str.strip()
df["Division Name"] = df["Division Name"].str.strip()

# Calculate centers per region
region_counts = df["Region"].value_counts().reset_index()
region_counts.columns = ["Region", "Number of Centers"]

# Calculate centers per division
division_counts = df["Division Name"].value_counts().reset_index()
division_counts.columns = ["Division Name", "Number of Centers"]

# Sort regions and divisions by number of centers
region_counts_sorted = region_counts.sort_values(by="Number of Centers", ascending=False)
division_counts_sorted = division_counts.sort_values(by="Number of Centers", ascending=False)

# Get top 5 and bottom 5 regions
top_5_regions = region_counts_sorted.head(5)
bottom_5_regions = region_counts_sorted.tail(5)

# Get top 10 and bottom 10 divisions
top_10_divisions = division_counts_sorted.head(10)
bottom_10_divisions = division_counts_sorted.tail(10)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the dashboard
app.layout = html.Div([
    # Title
    html.H1("Centers Analysis Dashboard", style={"textAlign": "center"}),
    
    # First Row: Bar Chart for Centers per Region
    html.Div([
        html.H3("Number of Centers per Region"),
        dcc.Graph(
            figure=px.bar(
                region_counts_sorted,
                x="Region",
                y="Number of Centers",
                labels={"Region": "Region", "Number of Centers": "Number of Centers"},
                title="Number of Centers per Region"
            )
        )
    ], className="visualization-card", style={"marginBottom": "40px"}),
    
    # Second Row: Top 5 and Bottom 5 Regions
    html.Div([
        # Top 5 Regions
        html.Div([
            html.H3("Top 5 Regions (Most Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in top_5_regions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "48%", "display": "inline-block"}),
        
        # Bottom 5 Regions
        html.Div([
            html.H3("Bottom 5 Regions (Fewest Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in bottom_5_regions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "48%", "display": "inline-block", "float": "right"})
    ], style={"marginBottom": "40px"}),
    
    # Third Row: Top 10 and Bottom 10 Divisions
    html.Div([
        # Top 10 Divisions
        html.Div([
            html.H3("Top 10 Divisions (Most Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Division Name"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Division Name"]), html.Td(row["Number of Centers"])])
                    for _, row in top_10_divisions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "48%", "display": "inline-block"}),
        
        # Bottom 10 Divisions
        html.Div([
            html.H3("Bottom 10 Divisions (Fewest Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Division Name"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Division Name"]), html.Td(row["Number of Centers"])])
                    for _, row in bottom_10_divisions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "48%", "display": "inline-block", "float": "right"})
    ], style={"marginBottom": "40px"}),
    
    # Fourth Row: Pie Chart for Distribution of Centers by Region
    html.Div([
        html.H3("Distribution of Centers by Region"),
        dcc.Graph(
            figure=px.pie(
                region_counts_sorted,
                names="Region",
                values="Number of Centers",
                title="Distribution of Centers by Region"
            )
        )
    ], className="visualization-card")
])

# Custom CSS
app.css.append_css({
    "external_url": "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
})

app.css.append_css({
    "external_url": "/assets/styles.css"  # Link to a local CSS file
})

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)