import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load the merged CSV file
df = pd.read_csv("merged_centers.csv")

# Initialize the Dash app
app = dash.Dash(__name__)

# Calculate summary statistics
total_regions = df["Region"].nunique()
total_divisions = df["Division Name"].nunique()

# Divisions per Region (sorted from high to low)
divisions_per_region = df.groupby("Region")["Division Name"].nunique().reset_index()
divisions_per_region.columns = ["Region", "Number of Divisions"]
divisions_per_region = divisions_per_region.sort_values(by="Number of Divisions", ascending=False)

# Centers per Division Grouped by Region
centers_per_division = df.groupby(["Region", "Division Name"]).size().reset_index()
centers_per_division.columns = ["Region", "Division Name", "Number of Centers"]

# Centers per Region (correct aggregation)
region_counts = df.groupby("Region").size().reset_index()
region_counts.columns = ["Region", "Number of Centers"]

# Define the layout of the dashboard
app.layout = html.Div([
    # Title
    html.H1("Centers Analysis Dashboard", style={"textAlign": "center"}),
    
    # First Row Section
    html.Div([
        # Total Regions
        html.Div([
            html.H3("Total Regions"),
            html.P(total_regions, style={"fontSize": "5em", "fontWeight": "bold"})
        ], className="stats-card", style={"width": "25%", "display": "inline-block", "marginLeft": "5%"}),
        
        # Total Divisions
        html.Div([
            html.H3("Total Divisions"),
            html.P(total_divisions, style={"fontSize": "5em", "fontWeight": "bold"})
        ], className="stats-card", style={"width": "25%", "display": "inline-block", "marginLeft": "5%"}),
        
        # Divisions per Region (10 columns, 2 rows)
        html.Div([
            html.H3("Divisions per Region"),
            html.Div([
                html.Div([
                    html.P(f"{row['Region']}: {row['Number of Divisions']}", style={"fontSize": "14px"})
                    for _, row in divisions_per_region.iloc[i:i+5].iterrows()
                ], style={"display": "inline-block", "width": "20%", "textAlign": "center"})
                for i in range(0, len(divisions_per_region), 5)
            ])
        ], className="stats-card", style={"width": "30%", "display": "inline-block", "marginLeft": "5%"})
    ], style={"marginBottom": "40px"}),
    
    # Second Row Section: Centers per Division (Bar Chart)
    html.Div([
        html.H3("Centers per Division"),
        dcc.Graph(
            figure=px.bar(
                centers_per_division,
                x="Division Name",
                y="Number of Centers",
                color="Region",
                labels={"Division Name": "Division", "Number of Centers": "Number of Centers"},
                title="Centers per Division (Colored by Region)"
            )
        )
    ], className="visualization-card", style={"marginBottom": "40px"}),
    
    # Third Row Section: Total Centers per Region (Bar Chart and Pie Chart)
    html.Div([
        # Bar Chart: Total Centers per Region
        html.Div([
            html.H3("Total Centers per Region"),
            dcc.Graph(
                figure=px.bar(
                    region_counts,
                    x="Region",
                    y="Number of Centers",
                    labels={"Region": "Region", "Number of Centers": "Number of Centers"},
                    title="Total Centers per Region"
                )
            )
        ], className="visualization-card", style={"width": "48%", "display": "inline-block"}),
        
        # Pie Chart: Distribution of Centers by Region
        html.Div([
            html.H3("Distribution of Centers by Region"),
            dcc.Graph(
                figure=px.pie(
                    region_counts,
                    names="Region",
                    values="Number of Centers",
                    title="Distribution of Centers by Region"
                )
            )
        ], className="visualization-card", style={"width": "48%", "display": "inline-block", "float": "right"})
    ])
])

# Custom CSS
app.css.append_css({
    "external_url": "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
})

app.css.append_css({
    "external_url": "/assets/styles.css"  # Link to a local CSS file
})

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)