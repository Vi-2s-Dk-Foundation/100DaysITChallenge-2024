import pandas as pd
import dash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output

# Load your CSV file
df = pd.read_csv("merged_centers.csv")  # Replace with your file name

# Calculate basic statistics
total_centers = len(df)
unique_regions = df['Region'].nunique()
unique_divisions = df['Division Name'].nunique()
top_regions = df['Region'].value_counts().head(5).reset_index()
top_divisions = df['Division Name'].value_counts().head(5).reset_index()
top_centers = df['Centre Name'].value_counts().head(5).reset_index()

# Center Name Pattern Analysis
def analyze_center_name_patterns(df):
    patterns = {
        "Government": df['Centre Name'].str.contains(r'(?i)Government', na=False).sum(),
        "External": df['Centre Name'].str.contains(r'(?i)External', na=False).sum(),
        "Secondary": df['Centre Name'].str.contains(r'(?i)Secondary', na=False).sum(),
        "High": df['Centre Name'].str.contains(r'(?i)High', na=False).sum(),
        "College": df['Centre Name'].str.contains(r'(?i)College', na=False).sum(),
        "Saint/St/St.": df['Centre Name'].str.contains(r'(?i)(Saint|St\.)', na=False).sum(),
    }
    return pd.DataFrame(list(patterns.items()), columns=['Pattern', 'Count'])

center_name_patterns = analyze_center_name_patterns(df)

# Initialize Dash app
app = dash.Dash(__name__)

# Dashboard layout
app.layout = html.Div(children=[
    html.H1("Centre Data Overview"),

    html.Div([
        html.Div([
            html.H3("Overall Counts"),
            html.P(f"Total Centres: {total_centers}"),
            html.P(f"Unique Regions: {unique_regions}"),
            html.P(f"Unique Divisions: {unique_divisions}"),
        ], style={'width': '30%', 'display': 'inline-block', 'padding': '10px'}),

        html.Div([
            html.H3("Top 5 Regions"),
            dash_table.DataTable(
                id='top-regions-table',
                columns=[{"name": i, "id": i} for i in top_regions.columns],
                data=top_regions.to_dict('records'),
                style_cell={'textAlign': 'left'},
            ),
        ], style={'width': '30%', 'display': 'inline-block', 'padding': '10px'}),
        html.Div([
            html.H3("Top 5 Divisions"),
            dash_table.DataTable(
                id='top-divisions-table',
                columns=[{"name": i, "id": i} for i in top_divisions.columns],
                data=top_divisions.to_dict('records'),
                style_cell={'textAlign': 'left'},
            ),
        ], style={'width': '30%', 'display': 'inline-block', 'padding': '10px'}),
    ]),

    html.Div([
        html.Div([
            html.H3("Top 5 Centre Names"),
            dash_table.DataTable(
                id='top-centers-table',
                columns=[{"name": i, "id": i} for i in top_centers.columns],
                data=top_centers.to_dict('records'),
                style_cell={'textAlign': 'left'},
            ),
        ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'}),

        html.Div([
            html.H3("Centre Name Patterns"),
            dash_table.DataTable(
                id='pattern-table',
                columns=[{"name": i, "id": i} for i in center_name_patterns.columns],
                data=center_name_patterns.to_dict('records'),
                style_cell={'textAlign': 'left'},
            ),
        ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'}),
    ]),
])

if __name__ == '__main__':
    app.run_server(debug=True)