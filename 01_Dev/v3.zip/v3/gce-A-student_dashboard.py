import dash
from dash import dcc, html, dash_table
import pandas as pd
import plotly.express as px

# Load the DataFrame from the PDF (output: csv)
df = pd.read_csv("2024-GCE-A.csv")

# Create Dash app
app = dash.Dash(__name__)

# Layout of the dashboard
app.layout = html.Div([
    html.H1("2024 GCE Advanced Levels - Students Dashboard", style={"textAlign": "center"}),
    
    # Filters
    html.Div([
        html.Label("Filter by Centre Name:"),
        dcc.Dropdown(
            id="centre-dropdown",
            options=[{"label": centre, "value": centre} for centre in df["Centre Name"].unique()],
            value=df["Centre Name"].unique()[0],  # Default value
            clearable=False,
            style={"width": "50%"}
        ),
        html.Br(),
        html.Label("Filter by Subjects Passed:"),
        dcc.Dropdown(
            id="subject-dropdown",
            options=[{"label": subject, "value": subject} for subject in sorted(df["Subjects Passed"].unique())],
            value=sorted(df["Subjects Passed"].unique()),  # Default value (all selected)
            multi=True,
            style={"width": "50%"}
        )
    ], style={"padding": "20px"}),
    
    
    # Charts
    html.Div([
        dcc.Graph(id="subject-bar-chart"),
        dcc.Graph(id="subject-pie-chart")
    ], style={"display": "flex", "justifyContent": "space-around", "padding": "20px"}),

    # Data Table
    dash_table.DataTable(
        id="student-table",
        columns=[{"name": col, "id": col} for col in df.columns],
        data=df.to_dict("records"),
        page_size=20,
        filter_action="native",
        sort_action="native",
        style_table={"height": "900px", "overflowY": "auto"},
        style_cell={"textAlign": "left", "padding": "10px"},
        style_header={"backgroundColor": "lightblue", "fontWeight": "bold"}
    ),
])

# Callback to update the table and charts based on filters
@app.callback(
    [dash.dependencies.Output("student-table", "data"),
     dash.dependencies.Output("subject-bar-chart", "figure"),
     dash.dependencies.Output("subject-pie-chart", "figure")],
    [dash.dependencies.Input("centre-dropdown", "value"),
     dash.dependencies.Input("subject-dropdown", "value")]
)
def update_dashboard(selected_centre, selected_subjects):
    # Filter the DataFrame
    filtered_df = df[(df["Centre Name"] == selected_centre) & (df["Subjects Passed"].isin(selected_subjects))]
    
    # Update the table
    table_data = filtered_df.to_dict("records")
    
    # Update the bar chart
    subject_counts = filtered_df["Subjects Passed"].value_counts().reset_index()
    subject_counts.columns = ["Subjects Passed", "count"]  # Rename columns
    bar_chart = px.bar(
        subject_counts,
        x="Subjects Passed",
        y="count",
        labels={"Subjects Passed": "Subjects Passed", "count": "Number of Students"},
        title=f"Distribution of Subjects Passed in {selected_centre}"
    )
    
    # Update the pie chart
    subject_counts = filtered_df["Subjects Passed"].value_counts().reset_index()
    subject_counts.columns = ["Subjects Passed", "count"]  # Rename columns
    pie_chart = px.pie(
        subject_counts,
        names="Subjects Passed",
        values="count",
        title=f"Percentage of Students by Subjects Passed in {selected_centre}"
    )
    return table_data, bar_chart, pie_chart

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)