import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load the merged CSV file
df = pd.read_csv("merged_centers.csv")

# Initialize the Dash app
app = dash.Dash(__name__)

# Calculate summary statistics
total_regions = df["Region"].nunique()
total_divisions = df["Division Name"].nunique()
divisions_per_region = df.groupby("Region")["Division Name"].nunique().reset_index()
divisions_per_region.columns = ["Region", "Number of Divisions"]
centers_per_division = df.groupby("Division Name").size().reset_index()
centers_per_division.columns = ["Division Name", "Number of Centers"]

# Prepare data for visualizations
region_counts = df["Region"].value_counts().reset_index()
region_counts.columns = ["Region", "Number of Centers"]  # Rename columns explicitly

# Define the layout of the dashboard
app.layout = html.Div([
    # Title
    html.H1("Centers Analysis Dashboard", style={"textAlign": "center"}),
    
    # Summary Statistics Grid
    html.Div([
        # Total Number of Regions
        html.Div([
            html.H3("Total Regions"),
            html.P(total_regions, style={"fontSize": "24px", "fontWeight": "bold"})
        ], className="stats-card"),
        
        # Total Number of Divisions
        html.Div([
            html.H3("Total Divisions"),
            html.P(total_divisions, style={"fontSize": "24px", "fontWeight": "bold"})
        ], className="stats-card"),
        
        # Number of Divisions per Region
        html.Div([
            html.H3("Divisions per Region"),
            html.Ul([
                html.Li(f"{row['Region']}: {row['Number of Divisions']}")
                for _, row in divisions_per_region.iterrows()
            ])
        ], className="stats-card"),
        
        # Number of Centers per Division
        html.Div([
            html.H3("Centers per Division"),
            html.Ul([
                html.Li(f"{row['Division Name']}: {row['Number of Centers']}")
                for _, row in centers_per_division.iterrows()
            ])
        ], className="stats-card")
    ], className="stats-grid"),
    
    # Visualizations Section
    html.Div([
        # Bar Chart: Centers by Region
        html.Div([
            html.H3("Centers by Region"),
            dcc.Graph(
                figure=px.bar(
                    region_counts,
                    x="Region",
                    y="Number of Centers",
                    labels={"Region": "Region", "Number of Centers": "Number of Centers"},
                    title="Number of Centers per Region"
                )
            )
        ], className="visualization-card"),
        
        # Pie Chart: Distribution of Centers by Region
        html.Div([
            html.H3("Distribution of Centers by Region"),
            dcc.Graph(
                figure=px.pie(
                    region_counts,
                    names="Region",
                    values="Number of Centers",
                    title="Distribution of Centers by Region"
                )
            )
        ], className="visualization-card")
    ], className="visualizations-grid")
])

# Custom CSS
app.css.append_css({
    "external_url": "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
})

app.css.append_css({
    "external_url": "/assets/styles.css"  # Link to a local CSS file
})

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)