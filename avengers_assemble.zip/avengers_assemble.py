# Avengers Assemble Word Game

# import random
import random

# List of Avengers
avengers = ['iron man', 'captain america', 'thor', 'hulk', 'black widow', 'hawkeye', 'spider man', 'black panther', 'doctor strange', 'captain marvel', 'scarlet witch', 'vision', 'falcon', 'war machine', 'ant man', 'wasp', ]

# Choose random word from list
word = random.choice(avengers).upper()

# Get length of word
word_length = len(word)

# Display word with dashes
word_display = '_ ' * word_length

# Records guess from user
guess = ""
guesses = set() # Use set instead of list
max_guesses = 5
good_guesses, bad_guesses = 0, 0

# Game info/intro
intro = "Welcome to Avengers Assemble! \nGuess the name of the Avenger. \nYou have 5 guesses. Good luck!"
print("*" * 90)
print(intro)
print("*" * 45)
print(f"GUESS the Avenger: {word_display}")

# Game loop
still_playing = True

while still_playing:
    # Get user input
    guess = input("Guess a letter or space: ").upper()

    # Validate input
    if len(guess) != 1:
        print("Please enter a single letter.")
        continue
    elif guess in guesses:
        print("You already guessed that letter.")
        continue
    elif not (guess.isalpha() or guess == " "):
        print("Please enter a letter or a space.")
        continue
    
    # Update guesses
    guesses.add(guess)
    
    # Check if guess is good or bad
    if guess in word:
        good_guesses += 1
        print(f"Good guess! {guess} is in the word.")
    else:
        bad_guesses += 1
        print(f"Bad guess! {guess} is not in the word.")
        
    # print outcome
    print(f"Guesses progress [Bad/Good/Total]: {bad_guesses}/{good_guesses}/{len(guesses)}")
    
    # Loop through word and print word_display
    word_display = ""
    for letter in word:
        if letter in guesses:
            word_display += letter + " "
        else:
            word_display += "_ "

    print(word_display) # Display word with dashes so far

    # Check if word_display is equal to word - END WIN
    if all(letter in guesses for letter in word):
        print(f"Congratulations! \nYou guessed the Avenger: {word}")
        still_playing = False
        
    # Check if guesses is equal to max_guesses - END LOSE
    if bad_guesses == max_guesses:
        print(f"Sorry! You have reached the max guesses. \nThe Avenger was: {word}")
        still_playing = False

# Version 2 of the code to make it more readable
# 1 more example of how to write the code