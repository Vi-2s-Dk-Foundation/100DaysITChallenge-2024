import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

# Load data from CSV
df = pd.read_csv("merged_centers.csv")

# Precompute descriptive statistics
total_centers = df["S/N"].count()
unique_regions = df["Region"].nunique()
unique_divisions = df["Division Name"].nunique()

# Total number of divisions in Cameroon (example: 58)
total_divisions_cameroon = 58
divisions_not_represented = total_divisions_cameroon - unique_divisions

# Frequency analysis
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "Count"]

# Centre Names Analysis
keywords = ["government", "external", "secondary", "high", "college"]
denominations = ["catholic", "protestant", "presbyterian", "baptist", "saint", "st"]

def check_patterns(name):
    name_lower = name.lower()
    keyword_count = sum(1 for word in keywords if word in name_lower)
    denomination_count = sum(1 for word in denominations if word in name_lower)
    return keyword_count, denomination_count

df[["Keyword Count", "Denomination Count"]] = df["Centre Name"].apply(
    lambda x: pd.Series(check_patterns(x))
)

keyword_freq = df["Keyword Count"].value_counts().reset_index()
keyword_freq.columns = ["Keyword Count", "Count"]

denomination_freq = df["Denomination Count"].value_counts().reset_index()
denomination_freq.columns = ["Denomination Count", "Count"]

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Layout
app.layout = dbc.Container([
    # Header
    dbc.Row([
        dbc.Col(html.H1("Centers Dashboard"), width=12)
    ]),
    
    # Descriptive Statistics Cards
    dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader("Total Centers"),
            dbc.CardBody(f"{total_centers}")
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Regions"),
            dbc.CardBody(f"{unique_regions}")
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Divisions in Data"),
            dbc.CardBody(f"{unique_divisions}")
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions in Cameroon"),
            dbc.CardBody(f"{total_divisions_cameroon}")
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions Not Represented"),
            dbc.CardBody(f"{divisions_not_represented}")
        ]), width=2)
    ]),
    
    # Frequency Analysis
    dbc.Row([
        dbc.Col(dcc.Graph(
            id="region-freq-chart",
            figure=px.bar(region_freq, x="Region", y="Count", title="Frequency of Centers by Region")
        ), width=6),
        dbc.Col(dcc.Graph(
            id="keyword-freq-chart",
            figure=px.bar(keyword_freq, x="Keyword Count", y="Count", title="Frequency of Keywords in Centre Names")
        ), width=6)
    ]),
    
    # Denominational Analysis
    dbc.Row([
        dbc.Col(dcc.Graph(
            id="denomination-freq-chart",
            figure=px.bar(denomination_freq, x="Denomination Count", y="Count", title="Frequency of Denominational Words in Centre Names")
        ), width=12)
    ])
])

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)