import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

# Load data from CSV
df = pd.read_csv("merged_centers.csv")

# Precompute descriptive statistics
total_centers = df["S/N"].count()
unique_regions = df["Region"].nunique()
unique_divisions = df["Division Name"].nunique()

# Total number of divisions in Cameroon (example: 58)
total_divisions_cameroon = 58
divisions_not_represented = total_divisions_cameroon - unique_divisions

# Frequency of Centers by Region
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "Count"]

# Centre Names Analysis
keywords = ["government", "external", "secondary", "high", "college"]
denominations = ["catholic", "protestant", "presbyterian", "baptist", "saint", "st"]

# Count occurrences of keywords in Centre Names
keyword_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in keywords}
keyword_freq = pd.DataFrame(list(keyword_counts.items()), columns=["Keyword", "Count"])

# Count occurrences of denominational words in Centre Names
denomination_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in denominations}
denomination_freq = pd.DataFrame(list(denomination_counts.items()), columns=["Denomination", "Count"])

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Layout
app.layout = dbc.Container([
    # Header
    dbc.Row([
        dbc.Col(html.H1("Centers Dashboard"), width=12)
    ]),
    
    # Descriptive Statistics Cards
    dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader("Total Centers"),
            dbc.CardBody(f"{total_centers}")
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Regions"),
            dbc.CardBody(f"{unique_regions}")
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Divisions in Data"),
            dbc.CardBody(f"{unique_divisions}")
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions in Cameroon"),
            dbc.CardBody(f"{total_divisions_cameroon}")
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions Not Represented"),
            dbc.CardBody(f"{divisions_not_represented}")
        ]), width=2)
    ]),
    
    # Frequency Analysis
    dbc.Row([
        dbc.Col(dcc.Graph(
            id="region-freq-chart",
            figure=px.bar(region_freq, x="Region", y="Count", title="Frequency of Centers by Region")
        ), width=6),
        dbc.Col(dcc.Graph(
            id="keyword-freq-chart",
            figure=px.bar(keyword_freq, x="Keyword", y="Count", title="Frequency of Keywords in Centre Names")
        ), width=6)
    ]),
    
    # Denominational Analysis
    dbc.Row([
        dbc.Col(dcc.Graph(
            id="denomination-freq-chart",
            figure=px.bar(denomination_freq, x="Denomination", y="Count", title="Frequency of Denominational Words in Centre Names")
        ), width=12)
    ])
])

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)