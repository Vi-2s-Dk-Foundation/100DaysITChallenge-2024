import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html

# Load data from CSV
df = pd.read_csv("all_centers.csv")

# Frequency analysis
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "count"]

print(region_freq.describe())
# Correct way to plot values, displaying the 'Value' column
fig = px.histogram(region_freq, x='Region', y='count', text_auto=True,
             title='Bar Chart Showing Values')

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H4('Bar Chart Showing Values'),
    dcc.Graph(id="region-bar-chart", figure=fig)
])

if __name__ == '__main__':
    app.run_server(debug=True)