import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load the merged CSV file
df = pd.read_csv("merged_centers.csv")

# Clean the Region and Division Name columns (remove leading/trailing spaces)
df["Region"] = df["Region"].str.strip()
df["Division Name"] = df["Division Name"].str.strip()

# Calculate global stats
total_regions_cameroon = 10  # Cameroon has 10 regions
total_divisions_cameroon = 58  # Cameroon has 58 divisions
total_regions_data = df["Region"].nunique()
total_divisions_data = df["Division Name"].nunique()

# Divisions per Region (sorted high to low)
divisions_per_region = df.groupby("Region")["Division Name"].nunique().reset_index()
divisions_per_region.columns = ["Region", "Number of Divisions"]
divisions_per_region = divisions_per_region.sort_values(by="Number of Divisions", ascending=False)

# Calculate centers per region
region_counts = df["Region"].value_counts().reset_index()
region_counts.columns = ["Region", "Number of Centers"]

# Calculate centers per division
division_counts = df.groupby(["Division Name", "Region"]).size().reset_index()
division_counts.columns = ["Division Name", "Region", "Number of Centers"]

# Sort regions and divisions by number of centers
region_counts_sorted = region_counts.sort_values(by="Number of Centers", ascending=False)
division_counts_sorted = division_counts.sort_values(by="Number of Centers", ascending=False)

# Get top 5 and bottom 5 regions
top_5_regions = region_counts_sorted.head(5)
bottom_5_regions = region_counts_sorted.tail(5)

# Get top 10 and bottom 10 divisions
top_10_divisions = division_counts_sorted.head(10)
bottom_10_divisions = division_counts_sorted.tail(10)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the dashboard
app.layout = html.Div([
    # Title
    html.H1("Centers Analysis Dashboard", style={"textAlign": "center"}),
    
    # Top Section: Global Stats
    html.Div([
        # Total Regions
        html.Div([
            html.H3("Total Regions in Cameroon"),
            html.P(total_regions_cameroon, style={"fontSize": "84px", "fontWeight": "bold"})
        ], className="stats-card", style={"width": "24%", "display": "inline-block"}),
        
        # Total Divisions in Cameroon
        html.Div([
            html.H3("Total Divisions in Cameroon"),
            html.P(total_divisions_cameroon, style={"fontSize": "84px", "fontWeight": "bold"})
        ], className="stats-card", style={"width": "24%", "display": "inline-block", "marginLeft": "1%"}),
        
        # Total Divisions in Data
        html.Div([
            html.H3("Total Divisions in Data"),
            html.P(total_divisions_data, style={"fontSize": "84px", "fontWeight": "bold"})
        ], className="stats-card", style={"width": "24%", "display": "inline-block", "marginLeft": "1%"}),
        
        # Divisions per Region (sorted)
        html.Div([
            html.H3("Divisions per Region (Sorted)"),
            html.Ul([
                html.Li(f"{row['Region']}: {row['Number of Divisions']}")
                for _, row in divisions_per_region.iterrows()
            ])
        ], className="stats-card", style={"width": "24%", "display": "inline-block", "marginLeft": "1%"})
    ], style={"marginBottom": "40px"}),
    
    # Mid Section: Top/Bottom Regions and Divisions
    html.Div([
        # Top 5 and Bottom 5 Regions (30% width)
        html.Div([
            html.H3("Top 5 Regions (Most Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in top_5_regions.iterrows()
                ])
            ]),
            html.H3("Bottom 5 Regions (Fewest Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in bottom_5_regions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "30%", "display": "inline-block"}),
        
        # Top 10 Divisions (35% width)
        html.Div([
            html.H3("Top 10 Divisions (Most Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Division Name"), html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Division Name"]), html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in top_10_divisions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "30%", "display": "inline-block", "marginLeft": "2%"}),
        
        # Bottom 10 Divisions (35% width)
        html.Div([
            html.H3("Bottom 10 Divisions (Fewest Centers)"),
            html.Table([
                html.Thead(html.Tr([html.Th("Division Name"), html.Th("Region"), html.Th("Number of Centers")])),
                html.Tbody([
                    html.Tr([html.Td(row["Division Name"]), html.Td(row["Region"]), html.Td(row["Number of Centers"])])
                    for _, row in bottom_10_divisions.iterrows()
                ])
            ])
        ], className="stats-card", style={"width": "30%", "display": "inline-block", "marginLeft": "2%"})
    ], style={"marginBottom": "40px"}),
    
    # Bottom Section: Distribution of Centers
    html.Div([
        # Bar Chart: Distribution of Centers per Region
        html.Div([
            html.H3("Distribution of Centers per Region"),
            dcc.Graph(
                figure=px.bar(
                    region_counts_sorted,
                    x="Region",
                    y="Number of Centers",
                    labels={"Region": "Region", "Number of Centers": "Number of Centers"},
                    title="Distribution of Centers per Region"
                )
            )
        ], className="visualization-card", style={"width": "48%", "display": "inline-block"}),
        
        # Pie Chart: Distribution of Centers by Region
        html.Div([
            html.H3("Distribution of Centers by Region"),
            dcc.Graph(
                figure=px.pie(
                    region_counts_sorted,
                    names="Region",
                    values="Number of Centers",
                    title="Distribution of Centers by Region"
                )
            )
        ], className="visualization-card", style={"width": "48%", "display": "inline-block", "float": "right"})
    ])
])

# Custom CSS
app.css.append_css({
    "external_url": "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
})

app.css.append_css({
    "external_url": "/assets/styles.css"  # Link to a local CSS file
})

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)