import dash
from dash import dcc, html, dash_table, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

# Load data
df = pd.read_csv("all_centers.csv")
all_divisions_df = pd.read_csv("all_divisions.csv")

# Clean column names
df.columns = df.columns.str.strip()
all_divisions_df.columns = all_divisions_df.columns.str.strip()

# Precompute statistics
total_centers = df["S/N"].count()
unique_regions = df["Region"].nunique()
unique_divisions = df["Division Name"].nunique()
total_divisions_cameroon = all_divisions_df["Division Name"].nunique()
divisions_not_represented = total_divisions_cameroon - unique_divisions

# Frequency of Centers by Region
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "Count"]

# Top 5 and Bottom 5 Regions
top_5_regions = region_freq.head(5)
bottom_5_regions = region_freq.tail(5)

# Frequency of Centers by Division
division_freq = df.groupby(["Division Name", "Region"]).size().reset_index(name="Count")

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
server = app.server  # Add this line to define the server variable

# Define tabs
app.layout = dbc.Container([
    html.H1("2024 GCE Centers Dashboard", style={"textAlign": "center", "color": "#343a40"}),
    dcc.Tabs(id="tabs", value="tab-1", children=[
        dcc.Tab(label="Overview", value="tab-1"),  # First tab for the original dashboard
        dcc.Tab(label="Interactive Analysis", value="tab-2")  # Second tab for enhancements
    ]),
    html.Div(id="tabs-content")  # Content for each tab will be rendered here
], fluid=True)

# Callback to render tab content
@app.callback(
    Output("tabs-content", "children"),
    Input("tabs", "value")
)
def render_tab_content(tab):
    if tab == "tab-1":
        top_5_regions_freq = df.groupby("Region").size().reset_index(name="Count").sort_values("Count", ascending=False).head(5)
        bottom_5_regions_freq = df.groupby("Region").size().reset_index(name="Count").sort_values("Count", ascending=True).head(5)


        # Content for the first tab (original dashboard)
        return dbc.Container([
            dbc.Row([
                dbc.Col(html.H3("National Statistics", style={"textAlign": "center"}), width=12)
            ]),
            dbc.Row([
                dbc.Col(dbc.Card([
                    dbc.CardHeader("Total Centers"),
                    dbc.CardBody(f"{total_centers}")
                ]), width=3),
                dbc.Col(dbc.Card([
                    dbc.CardHeader("Unique Regions"),
                    dbc.CardBody(f"{unique_regions}")
                ]), width=3),
                dbc.Col(dbc.Card([
                    dbc.CardHeader("Unique Divisions"),
                    dbc.CardBody(f"{unique_divisions}")
                ]), width=3),
                dbc.Col(dbc.Card([
                    dbc.CardHeader("Divisions Not Represented"),
                    dbc.CardBody(f"{divisions_not_represented}")
                ]), width=3)
            ]),
            dbc.Row([
                
                dbc.Col(dcc.Graph(
                    figure=px.bar(top_5_regions_freq, x="Region", y="Count", title="Top 5 Regions by Centers")
                ), width=6),
                dbc.Col(dcc.Graph(
                    figure=px.bar(bottom_5_regions_freq, x="Region", y="Count", title="Bottom 5 Regions by Centers")
                ), width=6)
            ])
        ])
    elif tab == "tab-2":
        # Content for the second tab (enhanced interactive analysis)
        return dbc.Container([
            dbc.Row([
                dbc.Col(html.H3("Interactive Analysis", style={"textAlign": "center"}), width=12)
            ]),
            dbc.Row([
                dbc.Col(dcc.Dropdown(
                    id='region-filter',
                    options=[{'label': region, 'value': region} for region in df['Region'].unique()],
                    multi=True,
                    placeholder="Select Region(s)",
                    value=df['Region'].unique()  # Default value (all regions selected)
                ), width=6),
                dbc.Col(dcc.Dropdown(
                    id='division-filter',
                    options=[{'label': division, 'value': division} for division in df['Division Name'].unique()],
                    multi=True,
                    placeholder="Select Division(s)",
                    value=df['Division Name'].unique()  # Default value (all divisions selected)
                ), width=6)
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='region-bar-chart'), width=6),
                dbc.Col(dcc.Graph(id='division-pie-chart'), width=6)
            ]),
            dbc.Row([
                dbc.Col(dash_table.DataTable(
                    id='interactive-table',
                    columns=[{"name": i, "id": i} for i in df.columns],
                    filter_action="native",
                    sort_action="native",
                    page_action="native",
                    page_size=10,
                    style_table={'height': '300px', 'overflowY': 'auto'}
                ), width=12)
            ])
        ])

# Callback for interactive components in Tab 2
@app.callback(
    [Output('region-bar-chart', 'figure'),
     Output('division-pie-chart', 'figure'),
     Output('interactive-table', 'data')],
    [Input('region-filter', 'value'),
     Input('division-filter', 'value')]
)
def update_interactive_tab(selected_regions, selected_divisions):
    # Filter the DataFrame based on dropdown selections
    filtered_df = df.copy()
    if selected_regions:
        filtered_df = filtered_df[filtered_df['Region'].isin(selected_regions)]
    if selected_divisions:
        filtered_df = filtered_df[filtered_df['Division Name'].isin(selected_divisions)]
    
    # Update bar chart
    region_counts = filtered_df.groupby('Region').size().reset_index(name='Count')
    bar_chart_figure = px.bar(
        region_counts,
        x='Region',
        y='Count',
        title="Centers by Region",
        labels={'Count': 'Number of Centers', 'Region': 'Region'}
    )
    
    # Update pie chart
    division_counts = filtered_df.groupby('Division Name').size().reset_index(name='Count')
    pie_chart_figure = px.pie(
        division_counts,
        names='Division Name',
        values='Count',
        title="Centers by Division",
        labels={'Count': 'Number of Centers', 'Division Name': 'Division'}
    )
    
    # Update table
    table_data = filtered_df.to_dict('records')
    
    return bar_chart_figure, pie_chart_figure, table_data

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)