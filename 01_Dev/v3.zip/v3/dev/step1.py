import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load the merged CSV file
df = pd.read_csv("merged_centers.csv")

# Initialize the Dash app
app = dash.Dash(__name__)

# National Overview
total_centers = df.shape[0]

# Region Overview
region_counts = df["Region"].value_counts().reset_index()
region_counts.columns = ["Region", "Number of Centers"]

# Division Overview
division_counts = df["Division Name"].value_counts().reset_index()
division_counts.columns = ["Division Name", "Number of Centers"]

# Define the layout of the dashboard
app.layout = html.Div([
    # Title
    html.H1("Centers Analysis Dashboard", style={"textAlign": "center"}),
    
    # National Overview
    html.Div([
        html.H3("National Overview"),
        html.P(f"Total Centers: {total_centers}")
    ], style={"margin": "20px"}),
    
    # Region Overview
    html.Div([
        html.H3("Region Overview"),
        html.P("Number of Centers per Region:"),
        dcc.Graph(
            figure=px.bar(
                region_counts,
                x="Region",
                y="Number of Centers",
                title="Centers by Region"
            )
        )
    ], style={"margin": "20px"}),
    
    # Division Overview
    html.Div([
        html.H3("Division Overview"),
        html.P("Number of Centers per Division:"),
        dcc.Graph(
            figure=px.bar(
                division_counts,
                x="Division Name",
                y="Number of Centers",
                title="Centers by Division"
            )
        )
    ], style={"margin": "20px"})
])

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)