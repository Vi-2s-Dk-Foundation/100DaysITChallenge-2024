import dash
from dash import dcc, html
import pandas as pd
import plotly.express as px

# Load the DataFrame from the PDF (output: csv)
df = pd.read_csv("2024-GCE-A.csv")

# Create Dash app
app = dash.Dash(__name__)

# Layout of the dashboard
app.layout = html.Div([
    html.H1("Student Results Dashboard", style={"textAlign": "center"}),
    dcc.Tabs([
        # Tab 1: Distribution of Students by Subjects Passed
        dcc.Tab(label="Subjects Distribution", children=[
            html.Div([
                dcc.Graph(
                    id="subject-bar-chart",
                    figure=px.bar(
                        df["Subjects Passed"].value_counts().reset_index().rename(columns={"index": "Subjects Passed", 0: "count"}),
                        x="Subjects Passed",
                        y="count",
                        labels={"Subjects Passed": "Subjects Passed", "count": "Number of Students"},
                        title="Distribution of Students by Subjects Passed"
                    )
                ),
                dcc.Graph(
                    id="subject-pie-chart",
                    figure=px.pie(
                        df["Subjects Passed"].value_counts().reset_index().rename(columns={"index": "Subjects Passed", 0: "count"}),
                        names="Subjects Passed",
                        values="count",
                        title="Percentage of Students by Subjects Passed"
                    )
                )
            ], style={"padding": "20px"})
        ]),

        # Tab 2: Performance by Centre
        dcc.Tab(label="Performance by Centre", children=[
            html.Div([
                dcc.Graph(
                    id="centre-bar-chart",
                    figure=px.bar(
                        df.groupby(["Centre Name", "Subjects Passed"]).size().reset_index(name="Number of Students"),
                        x="Centre Name",
                        y="Number of Students",
                        color="Subjects Passed",
                        barmode="group",
                        title="Performance by Centre",
                        labels={"Centre Name": "Centre Name", "Number of Students": "Number of Students"}
                    )
                ),
                dcc.Graph(
                    id="centre-heatmap",
                    figure=px.density_heatmap(
                        df.groupby(["Centre Name", "Subjects Passed"]).size().reset_index(name="Number of Students"),
                        x="Centre Name",
                        y="Subjects Passed",
                        z="Number of Students",
                        title="Performance Heatmap by Centre and Subjects Passed"
                    )
                )
            ], style={"padding": "20px"})
        ]),

        # Tab 3: Top Performing Centres
        dcc.Tab(label="Top Performing Centres", children=[
            html.Div([
                dcc.Graph(
                    id="top-centres-bar-chart",
                    figure=px.bar(
                        df["Centre Name"].value_counts().reset_index().rename(columns={"index": "Centre Name", 0: "count"}),
                        x="count",
                        y="Centre Name",
                        orientation="h",
                        title="Top Performing Centres",
                        labels={"Centre Name": "Centre Name", "count": "Number of Students"}
                    )
                )
            ], style={"padding": "20px"})
        ]),

        # Tab 4: Subject Performance Across Centres
        dcc.Tab(label="Subject Performance Across Centres", children=[
            html.Div([
                dcc.Graph(
                    id="subject-faceted-bar-chart",
                    figure=px.bar(
                        df.groupby(["Centre Name", "Subjects Passed"]).size().reset_index(name="Number of Students"),
                        x="Centre Name",
                        y="Number of Students",
                        color="Subjects Passed",
                        facet_col="Subjects Passed",
                        title="Subject Performance Across Centres",
                        labels={"Centre Name": "Centre Name", "Number of Students": "Number of Students"}
                    )
                )
            ], style={"padding": "20px"})
        ]),

    #     # Tab 5: Geographical Distribution of Centres
    #     dcc.Tab(label="Geographical Distribution", children=[
    #         html.Div([
    #             dcc.Graph(
    #                 id="centre-scatter-map",
    #                 figure=px.scatter_geo(
    #                     df,
    #                     lat="Latitude",
    #                     lon="Longitude",
    #                     color="Subjects Passed",
    #                     hover_name="Centre Name",
    #                     title="Geographical Distribution of Centres"
    #                 )
    #             )
    #         ], style={"padding": "20px"})
    #     ]),

    #     # Tab 6: Trends Over Time
    #     dcc.Tab(label="Trends Over Time", children=[
    #         html.Div([
    #             dcc.Graph(
    #                 id="trend-line-chart",
    #                 figure=px.line(
    #                     df.groupby(["Year", "Subjects Passed"]).size().reset_index(name="Number of Students"),
    #                     x="Year",
    #                     y="Number of Students",
    #                     color="Subjects Passed",
    #                     title="Trends in Student Performance Over Time",
    #                     labels={"Year": "Year", "Number of Students": "Number of Students"}
    #                 )
    #             )
    #         ], style={"padding": "20px"})
    #     ])
    # 
    ])
])

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)