import dash
from dash import dcc, html, dash_table
import dash_bootstrap_components as dbc
import pandas as pd

# Load data from CSV
df = pd.read_csv("all_centers.csv")
all_divisions_df = pd.read_csv("all_divisions.csv")

# Strip leading/trailing spaces from column names
df.columns = df.columns.str.strip()
all_divisions_df.columns = all_divisions_df.columns.str.strip()

# Precompute descriptive statistics
total_centers = df["S/N"].count()
unique_regions = df["Region"].nunique()
unique_divisions = df["Division Name"].nunique()

# Total number of divisions in Cameroon (from all_divisions.csv)
total_divisions_cameroon = all_divisions_df["Division Name"].nunique()
divisions_not_represented = total_divisions_cameroon - unique_divisions

# Frequency of Centers by Region
region_freq = df["Region"].value_counts().reset_index()
region_freq.columns = ["Region", "Count"]

# Top 5 and Bottom 5 Regions
top_5_regions = region_freq.head(5)
bottom_5_regions = region_freq.tail(5)

# Frequency of Centers by Division
division_freq = df.groupby(["Division Name", "Region"]).size().reset_index(name="Count")

# Top 10 and Bottom 10 Divisions
top_10_divisions = division_freq.nlargest(10, "Count")
bottom_10_divisions = division_freq.nsmallest(10, "Count")

# List of Divisions with No Centers
divisions_with_centers = df["Division Name"].unique()
divisions_with_no_centers = all_divisions_df[~all_divisions_df["Division Name"].isin(divisions_with_centers)]

# Centre Names Analysis
keywords = ["government", "external", "secondary", "high", "college"]
denominations = ["catholic", "protestant", "presbyterian", "baptist", "saint", "st"]

# Count occurrences of keywords in Centre Names
keyword_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in keywords}
keyword_freq = pd.DataFrame(list(keyword_counts.items()), columns=["Keyword", "Count"])

# Count occurrences of denominational words in Centre Names
denomination_counts = {word: df["Centre Name"].str.lower().str.contains(word).sum() for word in denominations}
denomination_freq = pd.DataFrame(list(denomination_counts.items()), columns=["Denomination", "Count"])

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Custom styles
card_style = {
    "textAlign": "center",
    "fontSize": "24px",
    "fontWeight": "bold",
    "border": "1px solid #ddd",
    "boxShadow": "2px 2px 5px rgba(0,0,0,0.1)"
}

header_style = {
    "textAlign": "center",
    "backgroundColor": "#f8f9fa",
    "padding": "10px",
    "borderBottom": "1px solid #ddd"
}

footer_style = {
    "backgroundColor": "#343a40",
    "color": "white",
    "textAlign": "center",
    "padding": "10px",
    "position": "fixed",
    "left": "0",
    "bottom": "0",
    "width": "100%"
}

# Layout
app.layout = dbc.Container([
    # Header
    dbc.Row([
        dbc.Col(html.H1("2024 GCE Centers Dashboard", style={"textAlign": "center"}), width=12),
        dbc.Col(html.P("Global Descriptive Statistics and Analysis", style={"textAlign": "center"}), width=12)
    ]),
    
    # Descriptive Statistics Cards
    dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader("Total Centers", style=header_style),
            dbc.CardBody(f"{total_centers}", style=card_style)
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Regions", style=header_style),
            dbc.CardBody(f"{unique_regions}", style=card_style)
        ]), width=3),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions in Cameroon", style=header_style),
            dbc.CardBody(f"{total_divisions_cameroon}", style=card_style)
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Unique Divisions in Data", style=header_style),
            dbc.CardBody(f"{unique_divisions}", style=card_style)
        ]), width=2),
        dbc.Col(dbc.Card([
            dbc.CardHeader("Divisions Not Represented", style=header_style),
            dbc.CardBody(f"{divisions_not_represented}", style=card_style)
        ]), width=2)
    ]),
    
    # Mid Section: 3 Columns
    dbc.Row([
        # Column 1: Stacked Top 5 and Bottom 5 Regions
        dbc.Col([
            html.H4("Top 5 Regions", style={"color": "green"}),
            dash_table.DataTable(
                columns=[{"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                data=top_5_regions.to_dict("records"),
                style_table={"height": "200px", "overflowY": "auto"},
                style_header={"backgroundColor": "green", "color": "white"}
            ),
            html.H4("Bottom 5 Regions", style={"color": "red"}),
            dash_table.DataTable(
                columns=[{"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                data=bottom_5_regions.to_dict("records"),
                style_table={"height": "200px", "overflowY": "auto"},
                style_header={"backgroundColor": "red", "color": "white"}
            )
        ], width=3),
        
        # Column 2: Top 10 Divisions
        dbc.Col([
            html.H4("Top 10 Divisions", style={"color": "green"}),
            dash_table.DataTable(
                columns=[{"name": "Division Name", "id": "Division Name"}, {"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                data=top_10_divisions.to_dict("records"),
                style_table={"height": "400px", "overflowY": "auto"},
                style_header={"backgroundColor": "green", "color": "white"}
            )
        ], width=3),
        
        # Column 3: Bottom 10 Divisions
        dbc.Col([
            html.H4("Bottom 10 Divisions", style={"color": "red"}),
            dash_table.DataTable(
                columns=[{"name": "Division Name", "id": "Division Name"}, {"name": "Region", "id": "Region"}, {"name": "Count", "id": "Count"}],
                data=bottom_10_divisions.to_dict("records"),
                style_table={"height": "400px", "overflowY": "auto"},
                style_header={"backgroundColor": "red", "color": "white"}
            )
        ], width=3),
        
        # Column 4: Divisions with No Centers
        dbc.Col([
            html.H4("Divisions with 0 Centers", style={"color": "gray"}),
            dash_table.DataTable(
                columns=[{"name": "Region", "id": "Region"}, {"name": "Division Name", "id": "Division Name"}],
                data=divisions_with_no_centers.to_dict("records"),
                style_table={"height": "400px", "overflowY": "auto"},
                style_header={"backgroundColor": "gray", "color": "white"}
            )
        ], width=3)
    ]),
    
    # Bottom Section: Keyword and Denominational Analysis
    dbc.Row([
        dbc.Col([
            html.H4("Keywords in Centre Names"),
            dash_table.DataTable(
                columns=[{"name": "Keyword", "id": "Keyword"}, {"name": "Count", "id": "Count"}],
                data=keyword_freq.to_dict("records"),
                style_table={"height": "200px", "overflowY": "auto"}
            )
        ], width=6),
        dbc.Col([
            html.H4("Denominational Words in Centre Names"),
            dash_table.DataTable(
                columns=[{"name": "Denomination", "id": "Denomination"}, {"name": "Count", "id": "Count"}],
                data=denomination_freq.to_dict("records"),
                style_table={"height": "200px", "overflowY": "auto"}
            )
        ], width=6)
    ]),
    
    # Footer
    html.Footer([
        html.P("© 2025 GCE Centers Dashboard. All rights reserved. Created by Vi-2s-Dk Foundation (vi2sdk.com)", style={"margin": "0"})
    ], style=footer_style)
])

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)