import random

# Functions = SRP - Single Responsibility Principle
def get_random_word(word_list):
    """Selects a random word from the given list."""
    return random.choice(word_list).upper()

def get_difficulty_level():
    """Prompts the user to select a difficulty level."""
    while True:
        difficulty = input("Choose difficulty: Easy (10 guesses), Medium (7 guesses), Hard (5 guesses): ").lower()
        if difficulty in ["easy", "medium", "hard"]:
            return difficulty
        else:
            print("Invalid difficulty. Please choose 'easy', 'medium', or 'hard'.")

def display_word(word, guesses):
    """Displays the word with guessed letters and underscores."""
    word_display = ""
    for letter in word:
        if letter in guesses:
            word_display += letter + " "
        else:
            word_display += "_ "
    return word_display

def play_game(word, max_guesses):
    """Plays a single round of the game."""
    guesses = set()
    good_guesses = 0
    bad_guesses = 0

    print(display_word(word, guesses))
    while bad_guesses < max_guesses:

        guess = input("Guess a letter: ").upper()

        # Validate input
        if not (guess.isalpha() or guess == " "):
            print("Please enter a single letter or a space.")
            continue
        if guess in guesses:
            print("You already guessed that letter.")
            continue

        guesses.add(guess)

        if guess in word:
            good_guesses += 1
            print(f"Good guess! {guess} is in the word.")
        else:
            bad_guesses += 1
            print(f"Bad guess! {guess} is not in the word.")
            print(f"Guesses progress [Bad/Good/Total]: {bad_guesses}/{good_guesses}/{len(guesses)}")

        print(display_word(word, guesses))

        if all(letter in guesses for letter in word):
            print(f"Congratulations! \nYou guessed the Avenger: {word}")
            return True
    
    print(f"Sorry! You have reached the max guesses. \nThe Avenger was: {word}")
    return False

def main():
    """Main function to run the game."""
    avengers = ['iron man', 'captain america', 'thor', 'hulk', 'black widow', 'hawkeye', 'spider man', 'black panther', 'doctor strange', 'captain marvel', 'scarlet witch', 'vision', 'falcon', 'war machine', 'ant man', 'wasp', ]

    difficulty = get_difficulty_level()

    if difficulty == "easy":
        max_guesses = 10
    elif difficulty == "medium":
        max_guesses = 7
    else:
        max_guesses = 5

    word = get_random_word(avengers)
    if play_game(word, max_guesses):
        print("You win!")
    else:
        print("You lose!")

if __name__ == "__main__":
    main()