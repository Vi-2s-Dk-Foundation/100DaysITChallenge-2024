import random
import tkinter as tk
from tkinter import messagebox
from avengers_assemble_v2 import get_random_word, get_difficulty_level, display_word

# Testing
# Game Flow
# Error Handling
# GUI
# Refactoring

# Use Pyinstaller to package GUI
# For distribution and sharing

def play_game(root, word, max_guesses):
    """Plays a single round of the game."""
    guesses = set()
    good_guesses = 0
    bad_guesses = 0

    word_label = tk.Label(root, text=display_word(word, guesses), font=("Helvetica", 18))
    word_label.pack(pady=10)

    guess_entry = tk.Entry(root, font=("Helvetica", 14))
    guess_entry.pack(pady=5)

    status_label = tk.Label(root, text="", font=("Helvetica", 12))
    status_label.pack(pady=5)

    guess_button = tk.Button(root, text="Guess", font=("Helvetica", 12), command=lambda: make_guess(word, guesses, good_guesses, bad_guesses, max_guesses, word_label, guess_entry, status_label))
    guess_button.pack(pady=5)

    root.mainloop()

def make_guess(word, guesses, good_guesses, bad_guesses, max_guesses, word_label, guess_entry, status_label):
    guess = guess_entry.get().upper()
    guess_entry.delete(0, 'end')

    if not (guess.isalpha() or guess == " "):
        status_label.config(text="Please enter a single letter or a space.")
        return

    if guess in guesses:
        status_label.config(text="You already guessed that letter.")
        return

    guesses.add(guess)

    if guess in word:
        good_guesses += 1
        status_label.config(text=f"Good guess! {guess} is in the word.")
    else:
        bad_guesses += 1
        status_label.config(text=f"Bad guess! {guess} is not in the word.")

    word_display = display_word(word, guesses)
    word_label.config(text=word_display)

    if all(letter in guesses for letter in word):
        messagebox.showinfo("Congratulations!", f"You guessed the Avenger: {word}")
        root.quit() 

    if bad_guesses == max_guesses:
        messagebox.showinfo("Game Over", f"Sorry! You have reached the max guesses. \nThe Avenger was: {word}")
        root.quit()

if __name__ == "__main__":
    avengers = ['iron man', 'captain america', 'thor', 'hulk', 'black widow', 'hawkeye', 'spider man', 'black panther', 'doctor strange', 'captain marvel', 'scarlet witch', 'vision', 'falcon', 'war machine', 'ant man', 'wasp', ]
    difficulty = get_difficulty_level()

    if difficulty == "easy":
        max_guesses = 10
    elif difficulty == "medium":
        max_guesses = 7
    else:
        max_guesses = 5

    word = get_random_word(avengers)

    root = tk.Tk()
    root.title("Avengers Assemble!")
    root.geometry("300x200")  # Set window size
    root.configure(bg="#f0f0f0")  # Set background color
    play_game(root, word, max_guesses)