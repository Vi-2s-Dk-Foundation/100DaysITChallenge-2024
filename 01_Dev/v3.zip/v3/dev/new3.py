import pandas as pd
import dash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output

# Load your CSV file
df = pd.read_csv("merged_centers.csv")  # Replace with your file name

# Calculate basic statistics
total_centers = len(df)
unique_regions = df['Region'].nunique()
unique_divisions = df['Division Name'].nunique()
top_regions = df['Region'].value_counts().reset_index()
top_regions.columns = ['Region', 'Centers']
top_divisions = df['Division Name'].value_counts().head(10).reset_index()
top_divisions.columns = ['Division Name', 'Centers']

# Add region to divisions for better context
top_divisions = pd.merge(top_divisions, df[['Division Name', 'Region']].drop_duplicates(), on='Division Name', how='left')

# Calculate divisions per region and centers per region/division
divisions_per_region = df.groupby('Region')['Division Name'].nunique().reset_index()
divisions_per_region.columns = ['Region', 'Divisions']
centers_per_region = df.groupby('Region')['Centre Name'].count().reset_index(name='Centers')
centers_per_division = df.groupby('Division Name')['Centre Name'].count().reset_index(name='Centers')

# Center Name Pattern Analysis (Christian denominations)
def analyze_center_name_patterns_christian(df):
    patterns = {
        "Catholic": df['Centre Name'].str.contains(r'(?i)Catholic', na=False).sum(),
        "Baptist": df['Centre Name'].str.contains(r'(?i)Baptist', na=False).sum(),
        "Protestant": df['Centre Name'].str.contains(r'(?i)Protestant', na=False).sum(),
        "Other Christian": df['Centre Name'].str.contains(r'(?i)(Christian|Church)', na=False).sum() -
                           df['Centre Name'].str.contains(r'(?i)(Catholic|Baptist|Protestant)', na=False).sum()
    }
    return pd.DataFrame(list(patterns.items()), columns=['Pattern', 'Count'])

center_name_patterns_christian = analyze_center_name_patterns_christian(df)

# Initialize Dash app
app = dash.Dash(__name__)

# Dashboard layout
app.layout = html.Div(children=[
    html.H1("Centre Data Overview", style={'textAlign': 'center'}),

    html.Div([
        html.Div([
            html.H3("Overall Counts", style={'textAlign': 'center'}),
            html.Div([
                html.P(f"Total Centres: {total_centers}", style={'fontSize': '20px'}),
                html.P(f"Unique Regions: {unique_regions}", style={'fontSize': '20px'}),
                html.P(f"Unique Divisions: {unique_divisions}", style={'fontSize': '20px'}),
            ], style={'display': 'flex', 'justifyContent': 'space-around'}),
        ], style={'backgroundColor': '#f0f0f0', 'padding': '20px', 'borderRadius': '5px', 'marginBottom': '20px'}),

        html.Div([
            html.Div([
                html.H3("Regions by Center Count", style={'textAlign': 'center'}),
                dash_table.DataTable(
                    id='top-regions-table',
                    columns=[{"name": i, "id": i} for i in top_regions.columns],
                    data=top_regions.to_dict('records'),
                    style_cell={'textAlign': 'left'},
                    style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
                ),
            ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'}),

            html.Div([
                html.H3("Top 10 Divisions by Center Count", style={'textAlign': 'center'}),
                dash_table.DataTable(
                    id='top-divisions-table',
                    columns=[{"name": i, "id": i} for i in top_divisions.columns],
                    data=top_divisions.to_dict('records'),
                    style_cell={'textAlign': 'left'},
                    style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
                ),
            ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'}),
        ]),
        html.Div([
            html.H3("Divisions per Region", style={'textAlign': 'center'}),
            dash_table.DataTable(
                id='divisions-per-region-table',
                columns=[{"name": i, "id": i} for i in divisions_per_region.columns],
                data=divisions_per_region.to_dict('records'),
                style_cell={'textAlign': 'left'},
                style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
                style_table={'width': '50%', 'margin': '0 auto'},
            )
        ], style = {'marginTop':'20px'})
    ], style={'padding': '20px'}),

    html.Div([
        html.Div([
            html.H3("Christian Center Name Patterns", style={'textAlign': 'center'}),
            dash_table.DataTable(
                id='pattern-table',
                columns=[{"name": i, "id": i} for i in center_name_patterns_christian.columns],
                data=center_name_patterns_christian.to_dict('records'),
                style_cell={'textAlign': 'left'},
                style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
                style_table={'width': '50%', 'margin': '0 auto'}
            ),
        ], style={'padding': '20px', 'textAlign':'center'}),
    ]),
    html.Div([
        html.H3("Centers per Region", style={'textAlign': 'center'}),
        dash_table.DataTable(
            id='centers-per-region-summary-table',
            columns=[{"name": i, "id": i} for i in centers_per_region.columns],
            data=centers_per_region.to_dict('records'),
            style_cell={'textAlign': 'left'},
            style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
            style_table={'width': '50%', 'margin': '0 auto'}
        )
    ], style = {'padding':'20px'}),
    html.Div([
        html.H3("Centers per Division", style={'textAlign': 'center'}),
        dash_table.DataTable(
            id='centers-per-division-summary-table',
            columns=[{"name": i, "id": i} for i in centers_per_division.columns],
            data=centers_per_division.to_dict('records'),
            style_cell={'textAlign': 'left'},
            style_header={'backgroundColor': '#ddd', 'fontWeight': 'bold'},
            style_table={'width': '50%', 'margin': '0 auto'}
        )
    ], style = {'padding':'20px'}),
])

if __name__ == '__main__':
    app.run_server(debug=True)